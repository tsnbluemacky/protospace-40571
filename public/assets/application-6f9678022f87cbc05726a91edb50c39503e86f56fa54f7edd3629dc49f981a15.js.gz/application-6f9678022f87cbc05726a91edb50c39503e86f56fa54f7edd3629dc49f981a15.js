import Rails from "@rails/ujs"
Rails.start();
